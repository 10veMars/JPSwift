//
//  HPTWebViewController.h
//  VOFun
//
//  Created by zenox on 2018/2/1.
//  Copyright © 2018年 James Hicklin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YJProgressHUD.h"

@interface HPTWebViewController : UIViewController

@property (nonatomic,assign) BOOL isMask;

@property (nonatomic,strong) NSString *Url;

@end
